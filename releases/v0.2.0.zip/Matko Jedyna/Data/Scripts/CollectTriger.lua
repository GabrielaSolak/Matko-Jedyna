local trigger = script.parent

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        -- dodanie punktów
        if other:GetResource("Points") == nil then
            other:SetResource("Points", 0)
        end
        other:AddResource("Points", 1)

        print("Zebrano! Punkty: " .. other:GetResource("Points"))

        -- usuń całą grupę Collectible
        if trigger.parent then
            trigger.parent:Destroy()
        end
    end
end

trigger.beginOverlapEvent:Connect(OnBeginOverlap)