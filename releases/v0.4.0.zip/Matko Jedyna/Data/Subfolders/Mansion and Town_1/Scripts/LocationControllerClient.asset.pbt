Assets {
  Id: 15331785326704994746
  Name: "LocationControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
