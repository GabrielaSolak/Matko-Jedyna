Assets {
  Id: 6004273052788222944
  Name: "BasicDoorControllerServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
