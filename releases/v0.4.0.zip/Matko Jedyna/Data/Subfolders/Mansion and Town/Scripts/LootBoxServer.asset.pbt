Assets {
  Id: 1132393827742168733
  Name: "LootBoxServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
