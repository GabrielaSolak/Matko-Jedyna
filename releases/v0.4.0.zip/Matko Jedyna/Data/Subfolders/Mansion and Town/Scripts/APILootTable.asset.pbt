Assets {
  Id: 7437136668386847436
  Name: "APILootTable"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
