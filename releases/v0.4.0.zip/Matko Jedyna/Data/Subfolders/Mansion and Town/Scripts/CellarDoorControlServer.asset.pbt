Assets {
  Id: 9056922615387424106
  Name: "CellarDoorControlServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
