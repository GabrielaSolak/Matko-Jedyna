local text = script.parent:FindChildByName("MainText")

Events.Connect("StartCleaning", function()
    text.text = "Syn nie posprzątał zabawek! Szybko!"
end)

Events.Connect("UpdatePoints", function(points)
    text.text = "Zebrano: " .. points
end)

Events.Connect("EndGame", function(time, result)
    text.text = "Czas: " .. time .. "s | Wynik: " .. result
end)