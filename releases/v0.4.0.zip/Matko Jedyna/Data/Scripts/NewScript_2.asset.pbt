Assets {
  Id: 13597908258125099652
  Name: "NewScript_2"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
