Assets {
  Id: 18074554242372412723
  Name: "TriggerScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
