Assets {
  Id: 4317123688246665303
  Name: "UI_ClientScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
