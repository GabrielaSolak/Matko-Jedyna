Assets {
  Id: 15581244232775021766
  Name: "DoorScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
