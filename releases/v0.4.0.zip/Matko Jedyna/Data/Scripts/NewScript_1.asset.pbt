Assets {
  Id: 7119763238411878711
  Name: "NewScript_1"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
