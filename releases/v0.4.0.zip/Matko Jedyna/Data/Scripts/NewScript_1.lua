local TEXT = script:GetCustomProperty("Text"):WaitForObject()

local messages = {
    "Spokojny dzień... aż nagle...",
    "DZWONEK DO DRZWI...",
    "TO TEŚCIOWA 😨",
    "Muszę ją dobrze ugościć...",
    "Najpierw... zupa dyniowa 🎃",
    "Potem trzeba ogarnąć dom...",
    "Zabawki wszędzie 😵",
    "Czas sprzątać i gotować!"
}

local delay = 2.5

function ShowMessages()
    for i, msg in ipairs(messages) do
        TEXT.text = msg
        Task.Wait(delay)
    end

    TEXT.text = "" -- znika na końcu
end

ShowMessages()