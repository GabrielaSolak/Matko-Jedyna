local trigger = script.parent

function OnBeginOverlap(trigger, other)
    if other:IsA("Player") then
        
        -- start timera
        _G.StartTime = time()

        -- reset punktów
        other:SetResource("Points", 0)

        -- komunikat startowy
        Events.BroadcastToPlayer(other, "StartCleaning")
    end
end

trigger.beginOverlapEvent:Connect(OnBeginOverlap)