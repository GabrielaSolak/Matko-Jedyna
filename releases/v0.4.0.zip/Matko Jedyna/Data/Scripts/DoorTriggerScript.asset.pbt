Assets {
  Id: 18191765281768426969
  Name: "DoorTriggerScript"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
