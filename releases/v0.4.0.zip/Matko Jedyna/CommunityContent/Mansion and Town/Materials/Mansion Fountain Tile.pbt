Assets {
  Id: 2660282410219379603
  Name: "Mansion Fountain Tile"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 17033856097141245795
    ParameterOverrides {
      Overrides {
        Name: "color"
        Color {
          R: 0.55
          G: 1
          B: 0.874834538
          A: 1
        }
      }
      Overrides {
        Name: "accent_color"
        Color {
          R: 0.79
          G: 0.879006624
          B: 1
          A: 1
        }
      }
      Overrides {
        Name: "material_scale"
        Float: 2
      }
    }
    Assets {
      Id: 17033856097141245795
      Name: "Ceramic Tiles Square 01"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mi_ceramic_tile_square_001"
      }
    }
  }
}
