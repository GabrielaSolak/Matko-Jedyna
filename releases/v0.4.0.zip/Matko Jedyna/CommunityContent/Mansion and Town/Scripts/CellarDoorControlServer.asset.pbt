Assets {
  Id: 13362234805752659742
  Name: "CellarDoorControlServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
