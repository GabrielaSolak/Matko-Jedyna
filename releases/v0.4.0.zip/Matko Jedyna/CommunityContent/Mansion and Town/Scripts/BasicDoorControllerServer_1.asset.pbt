Assets {
  Id: 6351000220611942832
  Name: "BasicDoorControllerServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
