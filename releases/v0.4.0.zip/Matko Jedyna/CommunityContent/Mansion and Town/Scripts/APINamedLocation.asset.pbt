Assets {
  Id: 2029671394043697028
  Name: "APINamedLocation"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
