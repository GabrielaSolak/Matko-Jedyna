Assets {
  Id: 5934731391059229476
  Name: "LocationControllerClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
