Assets {
  Id: 8590978532136263714
  Name: "APIObjectIcon"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
