Assets {
  Id: 4954087305427647977
  Name: "EquipmentAbilityChainServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
