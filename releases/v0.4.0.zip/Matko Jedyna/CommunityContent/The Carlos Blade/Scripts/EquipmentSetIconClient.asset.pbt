Assets {
  Id: 2111548062736381586
  Name: "EquipmentSetIconClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
