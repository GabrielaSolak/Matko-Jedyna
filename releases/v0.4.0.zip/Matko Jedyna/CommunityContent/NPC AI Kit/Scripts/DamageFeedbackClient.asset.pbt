Assets {
  Id: 7619577622638690557
  Name: "DamageFeedbackClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
