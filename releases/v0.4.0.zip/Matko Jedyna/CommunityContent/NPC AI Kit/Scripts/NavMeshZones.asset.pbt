Assets {
  Id: 4427225853057866482
  Name: "NavMeshZones"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:ModuleManager"
        AssetReference {
          Id: 8565240874411118340
        }
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
