Assets {
  Id: 6142649815563728640
  Name: "PlayerHomingTargets"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:PlayerHomingTarget"
        AssetReference {
          Id: 10160757139334128085
        }
      }
      Overrides {
        Name: "cs:PlayerHomingTarget:tooltip"
        String: "The invisible object to be attached to players for purposes of targeting homing shots."
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
