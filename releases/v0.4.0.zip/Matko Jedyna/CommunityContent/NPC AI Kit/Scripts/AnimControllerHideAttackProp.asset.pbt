Assets {
  Id: 5878339103440374919
  Name: "AnimControllerHideAttackProp"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:Root"
        ObjectReference {
        }
      }
      Overrides {
        Name: "cs:AttackProp"
        ObjectReference {
        }
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
