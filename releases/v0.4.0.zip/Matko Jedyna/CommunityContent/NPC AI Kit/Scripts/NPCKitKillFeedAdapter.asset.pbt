Assets {
  Id: 6592030971149995125
  Name: "NPCKitKillFeedAdapter"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
