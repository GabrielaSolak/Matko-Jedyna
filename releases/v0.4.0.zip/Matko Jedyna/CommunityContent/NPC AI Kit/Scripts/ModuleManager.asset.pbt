Assets {
  Id: 8565240874411118340
  Name: "ModuleManager"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
