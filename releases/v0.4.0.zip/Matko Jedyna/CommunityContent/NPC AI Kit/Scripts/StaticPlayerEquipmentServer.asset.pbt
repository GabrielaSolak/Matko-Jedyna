Assets {
  Id: 12345858880848233
  Name: "StaticPlayerEquipmentServer"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
