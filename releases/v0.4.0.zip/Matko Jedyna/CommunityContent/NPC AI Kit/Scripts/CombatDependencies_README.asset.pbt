Assets {
  Id: 5645429588765968635
  Name: "CombatDependencies_README"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
