Assets {
  Id: 2382234638999377971
  Name: "TargetRegister"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:Targeting_API"
        AssetReference {
          Id: 13857032121000676046
        }
      }
      Overrides {
        Name: "cs:DamageableObject"
        ObjectReference {
        }
      }
    }
  }
  SerializationVersion: 125
}
