Assets {
  Id: 4759195923798686055
  Name: "SpawnOnDestroy"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:SpawnOnDestroy"
        AssetReference {
          Id: 15720684328706431381
        }
      }
      Overrides {
        Name: "cs:Scale"
        Float: 1
      }
    }
  }
  SerializationVersion: 125
}
