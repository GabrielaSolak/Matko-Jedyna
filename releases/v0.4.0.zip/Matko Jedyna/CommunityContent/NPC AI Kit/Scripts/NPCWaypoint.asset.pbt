Assets {
  Id: 14281649316794553805
  Name: "NPCWaypoint"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
