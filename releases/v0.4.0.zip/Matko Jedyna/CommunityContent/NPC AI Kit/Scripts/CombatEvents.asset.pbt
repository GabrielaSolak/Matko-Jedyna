Assets {
  Id: 4770030284407086626
  Name: "CombatEvents"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
