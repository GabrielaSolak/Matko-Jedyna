Assets {
  Id: 3075970369795848368
  Name: "NPCKitArmor_Client"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
