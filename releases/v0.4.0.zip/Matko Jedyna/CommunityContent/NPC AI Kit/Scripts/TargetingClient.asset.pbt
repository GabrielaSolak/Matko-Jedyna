Assets {
  Id: 2983426978509468225
  Name: "TargetingClient"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:Targeting_API"
        AssetReference {
          Id: 13857032121000676046
        }
      }
      Overrides {
        Name: "cs:UIContainer"
        ObjectReference {
        }
      }
      Overrides {
        Name: "cs:UIImage"
        ObjectReference {
        }
      }
      Overrides {
        Name: "cs:LookSpeed"
        Float: 5
      }
      Overrides {
        Name: "cs:RotationSpeed"
        Float: -60
      }
    }
  }
  SerializationVersion: 125
}
