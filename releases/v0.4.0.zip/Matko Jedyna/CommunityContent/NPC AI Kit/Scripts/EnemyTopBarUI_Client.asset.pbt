Assets {
  Id: 7617707511588345597
  Name: "EnemyTopBarUI_Client"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:HealthBarScript"
        ObjectReference {
        }
      }
    }
  }
  SerializationVersion: 125
}
