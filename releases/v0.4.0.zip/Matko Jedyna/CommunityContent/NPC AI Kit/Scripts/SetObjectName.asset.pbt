Assets {
  Id: 11028901855447265604
  Name: "SetObjectName"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
      Overrides {
        Name: "cs:ModuleManager"
        AssetReference {
          Id: 8565240874411118340
        }
      }
      Overrides {
        Name: "cs:TargetObject"
        ObjectReference {
        }
      }
      Overrides {
        Name: "cs:NameToSet"
        String: "?"
      }
      Overrides {
        Name: "cs:TargetObject:tooltip"
        String: "Probably point this to the root of the template, but can be used to rename any object at runtime."
      }
      Overrides {
        Name: "cs:NameToSet:tooltip"
        String: "The new name to set on the object."
      }
    }
  }
  SerializationVersion: 125
  VirtualFolderPath: "NPC Kit"
}
