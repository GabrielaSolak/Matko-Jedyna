Assets {
  Id: 17558729805188695237
  Name: "EnemyTopBarUI_Server"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
