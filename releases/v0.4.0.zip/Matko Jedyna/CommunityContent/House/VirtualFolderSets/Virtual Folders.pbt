Assets {
  Id: 3216966687606716309
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
  }
}
