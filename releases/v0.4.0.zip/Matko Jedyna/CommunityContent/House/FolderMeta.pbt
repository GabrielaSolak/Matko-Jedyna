MetaVersion: 1
MarketplaceDetails {
  Id: "a885f26bf96841348f40986695673361"
  OwnerAccountId: "bdde6f83d6e945c69269b1d0d9d120e8"
  OwnerName: "Knightova"
  Version: "1.0.0"
}
AssetIdsOriginalToNew {
  key: 463979792830901343
  value: 13537859575716908234
}
AssetIdsOriginalToNew {
  key: 3205018944911699611
  value: 11569999446439534831
}
AssetIdsOriginalToNew {
  key: 7129961543899393423
  value: 3292911804299506241
}
