Assets {
  Id: 3292911804299506241
  Name: "Custom Floor from Craftsman Floor 01 8m x 8m"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 14067680337084195968
    ParameterOverrides {
      Overrides {
        Name: "rotate_material"
        Float: 0
      }
    }
    Assets {
      Id: 14067680337084195968
      Name: "Craftsman Hardwood Floor"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mi_trim_craftsman_floor"
      }
    }
  }
}
