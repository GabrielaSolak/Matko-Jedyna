Assets {
  Id: 15065130402992729954
  Name: "Custom  Wood 9 Slice Crate 01"
  PlatformAssetType: 13
  SerializationVersion: 125
  CustomMaterialAsset {
    BaseMaterialId: 17310112631392498600
    ParameterOverrides {
    }
    Assets {
      Id: 17310112631392498600
      Name: " Wood 9 Slice Crate 01"
      PlatformAssetType: 2
      PrimaryAsset {
        AssetType: "MaterialAssetRef"
        AssetId: "mat_advanced_9slice_wooden_crates_001_ref"
      }
    }
  }
}
