MetaVersion: 1
MarketplaceDetails {
  Id: "70325b862e254774bb92023bec3582f9"
  OwnerAccountId: "e18597c8335842849b40a2ef8647e700"
  OwnerName: "buwayayay"
  Version: "1.0.0"
}
AssetIdsOriginalToNew {
  key: 604351003700248276
  value: 10653696151571013215
}
AssetIdsOriginalToNew {
  key: 15945727969804883918
  value: 13834233471018397194
}
