Assets {
  Id: 10653696151571013215
  Name: "small house"
  PlatformAssetType: 5
  TemplateAsset {
    ObjectBlock {
      RootId: 13493965990957081500
      Objects {
        Id: 13493965990957081500
        Name: "TemplateBundleDummy"
        Transform {
          Location {
          }
          Rotation {
          }
          Scale {
            X: 1
            Y: 1
            Z: 1
          }
        }
        CameraCollidable {
          Value: "mc:ecollisionsetting:inheritfromparent"
        }
        Folder {
          BundleDummy {
            ReferencedAssets {
              Id: 13834233471018397194
            }
          }
        }
        NetworkRelevanceDistance {
          Value: "mc:eproxyrelevance:critical"
        }
        IsReplicationEnabledByDefault: true
      }
    }
    PrimaryAssetId {
      AssetType: "None"
      AssetId: "None"
    }
  }
  Marketplace {
    Id: "70325b862e254774bb92023bec3582f9"
    OwnerAccountId: "e18597c8335842849b40a2ef8647e700"
    OwnerName: "buwayayay"
    Version: "1.0.0"
    Description: "a small house"
  }
  SerializationVersion: 125
}
