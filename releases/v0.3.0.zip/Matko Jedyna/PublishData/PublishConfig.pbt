GameId: "3abe8b4931284e35bc559443a053ebce"
ClientVersion: "1.0.298-prod-s"
Name: "Matko jedyna"
Description: "Matko jedyna - gra edukacyjna"
IsOpenForEdit: true
Tags: "Action"
ScreenshotPaths: "C:/Users/jbial/Documents/My Games/Core/Saved/Maps/Matko jedyna/Screenshots/Screenshot0001.png"
ReleaseNotes: "@f okej "
OwnerId: "4db8cfcb307b411a95d329c7a484fe2a"
SerializationVersion: 4
PublishedState: Public
IsQueued: true
MinPlayersToStart: 8
PreventJoinAsParty: true
SceneNameToSceneIdMap {
  key: "Main"
  value: "d0c346e0482efa6deed1f8ba52a53846"
}
MaxPlayersForMainScene: 8
EnableForPC: true
EnableForMobile: true
