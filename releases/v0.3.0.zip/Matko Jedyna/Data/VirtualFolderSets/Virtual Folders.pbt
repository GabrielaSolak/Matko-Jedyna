Assets {
  Id: 11237267171393895703
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
    Folders {
      VirtualFolderPath: "New Folder"
      PlatformAssetType: 5
    }
    Folders {
      VirtualFolderPath: "New Folder_1"
      PlatformAssetType: 5
    }
  }
}
