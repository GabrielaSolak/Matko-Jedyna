local parent = script.parent
local text = parent:FindChildByName("MainText")

if not text then
    warn("Nie znaleziono MainText!")
    return
end

Events.Connect("StartCleaning", function()
    text.text = "Syn nie posprzątał zabawek i narozrabiał! Szybko!"
end)

Events.Connect("UpdatePoints", function(points)
    text.text = "Zebrano: " .. points
end)

Events.Connect("EndGame", function(time, result)
    text.text = "Czas: " .. time .. "s | Wynik: " .. result
end)