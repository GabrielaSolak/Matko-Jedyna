Assets {
  Id: 8494399172914688005
  Name: "Virtual Folders"
  PlatformAssetType: 30
  SerializationVersion: 125
  VirtualFolderSetAsset {
  }
}
