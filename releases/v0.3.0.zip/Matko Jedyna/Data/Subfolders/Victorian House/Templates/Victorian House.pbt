Assets {
  Id: 5838181433791985229
  Name: "Victorian House"
  PlatformAssetType: 5
  TemplateAsset {
    ObjectBlock {
      RootId: 6831152308793730908
      Objects {
        Id: 6831152308793730908
        Name: "TemplateBundleDummy"
        Transform {
          Location {
          }
          Rotation {
          }
          Scale {
            X: 1
            Y: 1
            Z: 1
          }
        }
        CameraCollidable {
          Value: "mc:ecollisionsetting:inheritfromparent"
        }
        Folder {
          BundleDummy {
            ReferencedAssets {
              Id: 17967411522406746074
            }
          }
        }
        NetworkRelevanceDistance {
          Value: "mc:eproxyrelevance:critical"
        }
        IsReplicationEnabledByDefault: true
      }
    }
    PrimaryAssetId {
      AssetType: "None"
      AssetId: "None"
    }
  }
  Marketplace {
    Id: "50d94895180c494db6eacfad670b9f2d"
    OwnerAccountId: "02b8b0373d2d4f1e8cf659d835e675b3"
    OwnerName: "elmartipro"
    Version: "1.0.0"
    Description: "Victorian House Core Royale"
  }
  SerializationVersion: 125
}
