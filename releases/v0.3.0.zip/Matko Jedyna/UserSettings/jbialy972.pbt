ObjectSettings {
  ObjectStates {
    key: 841534158063459245
    value {
      IsLocked: true
    }
  }
  ObjectStates {
    key: 10529887036693542732
    value {
      IsLocked: true
    }
  }
}
LastSavedScene: "Main"
PreviewDetailLevelPerScene {
  key: "Main"
  value: 0
}
