ObjectSettings {
  ObjectStates {
    key: 841534158063459245
    value {
      IsLocked: true
    }
  }
  ObjectStates {
    key: 10808368244524322507
    value {
      IsHidden: true
    }
  }
  ObjectStates {
    key: 14667783467848045125
    value {
    }
  }
}
LastSavedScene: "Main"
