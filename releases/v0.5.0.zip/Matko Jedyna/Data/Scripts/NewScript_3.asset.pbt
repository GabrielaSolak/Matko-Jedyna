Assets {
  Id: 12187366158198464607
  Name: "NewScript_3"
  PlatformAssetType: 3
  TextAsset {
    CustomParameters {
    }
  }
  SerializationVersion: 125
}
